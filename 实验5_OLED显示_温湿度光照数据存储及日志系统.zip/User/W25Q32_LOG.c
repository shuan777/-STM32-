#include "W25Q32_LOG.h"
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"                  // Device header
#include "driver_oled.h"

/* ---------------- оƬ������ ---------------- */
#define CMD_WREN      0x06
#define CMD_WRDI      0x04
#define CMD_READ      0x03
#define CMD_PP        0x02    // Page Program
#define CMD_SE        0x20    // Sector Erase 4KB
#define CMD_RDSR1     0x05

/* ---------------- ���ó��� ---------------- */
#define SECTOR_SIZE   4096UL
#define PAGE_SIZE     256UL
#define LOG_MAX_SEC   64          // ��ǰ 64 ����
#define LOG_REC_SZ    sizeof(LOG_T)

/* ---------------- �ײ����ź� ---------------- */
#define W25Q32_CS_LOW()   GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define W25Q32_CS_HIGH()  GPIO_SetBits(GPIOA, GPIO_Pin_4)

/* ---------------- �ײ㺯������ ---------------- */
static void    MySPI1_Init(void);           // �ϵ����һ��
static uint8_t SPI_RW(uint8_t data);
static void    W25Q32_WaitBusy(void);
static void    W25Q32_WriteEnable(void);
static void    W25Q32_EraseSector(uint32_t addr);
static void    W25Q32_WritePage(uint32_t addr, uint8_t *buf, uint16_t len);
static void    W25Q32_ReadData(uint32_t addr, uint8_t *buf, uint32_t len);

/* ---------------- ��־˽�б��� ---------------- */
static uint16_t gSec = 0;   // ��ǰд����
static uint16_t gOff = 0;   // ������ƫ��

/* =================================================================== */
/*                      �ײ� SPI ��������׼�⣩                          */
/* =================================================================== */
static void MySPI1_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1, ENABLE);

    GPIO_InitTypeDef gpio = {0};
    // PA5/SCK  PA7/MOSI
    gpio.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);
    // PA4/CS
    gpio.GPIO_Pin = GPIO_Pin_4;
    gpio.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &gpio);
    W25Q32_CS_HIGH();

    SPI_InitTypeDef spi = {0};
    spi.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    spi.SPI_Mode = SPI_Mode_Master;
    spi.SPI_DataSize = SPI_DataSize_8b;
    spi.SPI_CPOL = SPI_CPOL_High;
    spi.SPI_CPHA = SPI_CPHA_2Edge;
    spi.SPI_NSS = SPI_NSS_Soft;
    spi.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
    spi.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &spi);
    SPI_Cmd(SPI1, ENABLE);
}

static uint8_t SPI_RW(uint8_t data)
{
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, data);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
    return SPI_I2S_ReceiveData(SPI1);
}

/* =================================================================== */
/*                      W25Q32 ԭ�Ӳ���                                  */
/* =================================================================== */
static void W25Q32_WaitBusy(void)
{
    uint8_t status;
    W25Q32_CS_LOW();
    SPI_RW(CMD_RDSR1);
    do {
        status = SPI_RW(0xFF);
    } while (status & 0x01);
    W25Q32_CS_HIGH();
}

static void W25Q32_WriteEnable(void)
{
    W25Q32_CS_LOW();
    SPI_RW(CMD_WREN);
    W25Q32_CS_HIGH();
}

static void W25Q32_EraseSector(uint32_t addr)
{
    W25Q32_WaitBusy();
    W25Q32_WriteEnable();
    W25Q32_CS_LOW();
    SPI_RW(CMD_SE);
    SPI_RW((addr >> 16) & 0xFF);
    SPI_RW((addr >> 8) & 0xFF);
    SPI_RW(addr & 0xFF);
    W25Q32_CS_HIGH();
    W25Q32_WaitBusy();
}

static void W25Q32_WritePage(uint32_t addr, uint8_t *buf, uint16_t len)
{
    if (len > PAGE_SIZE) len = PAGE_SIZE;
    W25Q32_WaitBusy();
    W25Q32_WriteEnable();
    W25Q32_CS_LOW();
    SPI_RW(CMD_PP);
    SPI_RW((addr >> 16) & 0xFF);
    SPI_RW((addr >> 8) & 0xFF);
    SPI_RW(addr & 0xFF);
    for (uint16_t i = 0; i < len; i++) SPI_RW(buf[i]);
    W25Q32_CS_HIGH();
    W25Q32_WaitBusy();
}

static void W25Q32_ReadData(uint32_t addr, uint8_t *buf, uint32_t len)
{
    W25Q32_CS_LOW();
    SPI_RW(CMD_READ);
    SPI_RW((addr >> 16) & 0xFF);
    SPI_RW((addr >> 8) & 0xFF);
    SPI_RW(addr & 0xFF);
    for (uint32_t i = 0; i < len; i++) buf[i] = SPI_RW(0xFF);
    W25Q32_CS_HIGH();
}

/* =================================================================== */
/*                      ��־�߼���                                       */
/* =================================================================== */
void LOG_Init(void)
{
    MySPI1_Init();                      // һ���Գ�ʼ�� SPI ���� & ʱ��
    uint8_t buf[LOG_REC_SZ];
    for (gSec = 0; gSec < LOG_MAX_SEC; gSec++) {
        for (gOff = 0; gOff < SECTOR_SIZE; gOff += LOG_REC_SZ) {
            uint32_t addr = gSec * SECTOR_SIZE + gOff;
            W25Q32_ReadData(addr, buf, LOG_REC_SZ);
            if (buf[0] == 0xFF && buf[1] == 0xFF) {   // �ռ�¼
                return;
            }
        }
    }
    /* д�����ص���ͷ */
    gSec = 0;
    gOff = 0;
}

uint8_t LOG_Write(LOG_T *rec)
{
    static uint32_t tick = 0;
    rec->time = tick++;

    uint32_t addr = gSec * SECTOR_SIZE + gOff;
    uint8_t  buf[LOG_REC_SZ];
    memcpy(buf, rec, LOG_REC_SZ);          // �ṹ�� �� �ֽ���

    /* 1. �������Ȳ��� */
    if (gOff == 0) {
        W25Q32_EraseSector(addr);
    }

    /* 2. ҳ��д�루10 B ������ҳ�� */
    W25Q32_WritePage(addr, buf, LOG_REC_SZ);
    gOff += LOG_REC_SZ;

    /* 3. �����ؾ� */
    if (gOff >= SECTOR_SIZE) {
        gOff = 0;
        gSec++;
        if (gSec >= LOG_MAX_SEC) gSec = 0;
    }
    return 0;
}

uint8_t LOG_ReadLast(LOG_T *rec)
{
    if (gSec == 0 && gOff == 0) return 1;
    uint32_t total = gSec * (SECTOR_SIZE / LOG_REC_SZ) + gOff / LOG_REC_SZ;
    uint32_t addr  = ((total - 1) * LOG_REC_SZ) % (LOG_MAX_SEC * SECTOR_SIZE);
    uint8_t  buf[LOG_REC_SZ];
    W25Q32_ReadData(addr, buf, LOG_REC_SZ);
    memcpy(rec, buf, LOG_REC_SZ);          // �ֽ��� �� �ṹ��
    return 0;
}

uint8_t LOG_ReadByIndex(uint16_t idx, LOG_T *rec)
{
    uint32_t total = gSec * (SECTOR_SIZE / LOG_REC_SZ) + gOff / LOG_REC_SZ;
    if (idx >= total) return 1;
    uint32_t addr = ((total - 1 - idx) * LOG_REC_SZ) % (LOG_MAX_SEC * SECTOR_SIZE);
    uint8_t buf[LOG_REC_SZ];
    W25Q32_ReadData(addr, buf, LOG_REC_SZ);
    memcpy(rec, buf, LOG_REC_SZ);
    return 0;
}

void LOG_DumpLast(uint16_t cnt)
{
    LOG_T rec;
    printf("\r\n----- W25Q32 ��� %d �� -----\r\n", cnt);
    for (uint16_t i = 0; i < cnt; i++) {
        if (LOG_ReadByIndex(i, &rec) == 0) {
            printf("[%05u] T=%.1f  H=%.1f  L=%u\r\n",
                   rec.time, rec.temp / 10.0f, rec.humi / 10.0f, rec.lux);
        }
    }
}

void LOG_ShowLast(uint8_t line)
{
    LOG_T rec;
    if (LOG_ReadLast(&rec) != 0) {          // ������
        OLED_ShowString(0, line, "No Log!");
        return;
    }

    /* һ�� 128 ���أ���ʽ��T25.6 H58.0 L365 */
    char buf[20];
	sprintf(buf, "T%2d.%1dH%2d.%1dL%3u",
        rec.temp / 10, abs(rec.temp % 10),   // �¶�
        rec.humi / 10, rec.humi % 10,        // ʪ��
        rec.lux);                            // ����
    OLED_ShowString(0, line, buf);
}

/* ��ʾ 1 ����־��T25 H58 L365  �� 11 �ַ� */
static void OLED_ShowOneLog(uint8_t line, LOG_T *rec)
{
    char buf[16];
    /* ȫ���������޸��� */
    sprintf(buf, "T%2d H%3d L%4d", rec->temp, rec->humi, rec->lux);
    OLED_ShowString(0, line, buf);
}

/* ����ҳ����ʾ��page=0 ���� 4 ����page=1 �� 4~7 �� ... */
void LOG_ShowPage(uint8_t page)
{
    LOG_T rec;
    uint8_t base = page * 4;          // ��ʼ���
    for (uint8_t i = 0; i < 4; i++)   // ÿҳ 4 ��
    {
        if (LOG_ReadByIndex(base + i, &rec) == 0)
            OLED_ShowOneLog(i * 2, &rec);      // ÿ��ռ 2 ���ַ��������ص�
        else
            OLED_ShowString(0, i * 2, "  ----"); // ������
    }
}

uint32_t LOG_Count(void)
{
    return (gSec * (SECTOR_SIZE / LOG_REC_SZ) + gOff / LOG_REC_SZ);
}

/*  dump ȫ��������š����ºţ�����ȫ���� float */
void LOG_DumpAll(void)
{
    uint32_t total = LOG_Count();
    if (total == 0) {
        printf("\r\n----- W25Q32 ����־ -----\r\n");
        return;
    }

    printf("\r\n----- W25Q32 �� %lu �� -----\r\n", total);
    for (uint32_t idx = 0; idx < total; idx++) {
        LOG_T rec;
        if (LOG_ReadByIndex(idx, &rec) == 0) {
            /* �Ŵ� 10 ����ʾ��ȫ������ */
            printf("[%05u] T%2d.%1d  H%2d.%1d  L%4u\r\n",
                   rec.time,
                   rec.temp / 10, abs((int)(rec.temp % 10)),
                   rec.humi / 10, rec.humi % 10,
                   rec.lux);
        }
    }
}
