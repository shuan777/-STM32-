#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "buzzer.h"

/* �� */
#define LED_PIN  GPIO_Pin_13
#define LED_PORT GPIOC

/* ��� */
static QueueHandle_t xRxQueue;
static TimerHandle_t xLedTmr;
static TimerHandle_t xBuzzerTimer = NULL;

/* ����ԭ�� */
static void vHeartTask(void *p);
static void vUartTask(void *p);
static void tmrLedCB(TimerHandle_t t);

/* �жϷ����� --------------------------------------------------*/
void USART1_IRQHandler(void)
{
    uint8_t dat;
    BaseType_t xHPW = pdFALSE;
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        dat = USART_ReceiveData(USART1);
        xQueueSendFromISR(xRxQueue, &dat, &xHPW);
        portEND_SWITCHING_ISR(xHPW);
    }
}

/* main ---------------------------------------------------------*/
int main(void)
{
    /* 1. ʱ�� */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOA |
                           RCC_APB2Periph_USART1, ENABLE);

    /* 2. ���ȼ����� */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    /* 3. LED */
    GPIO_InitTypeDef gpio = { LED_PIN, GPIO_Speed_50MHz, GPIO_Mode_Out_PP };
    GPIO_Init(LED_PORT, &gpio);

    /* 4. USART1 TX=PA9  RX=PA10 */
    gpio.GPIO_Pin = GPIO_Pin_9;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpio);
    gpio.GPIO_Pin = GPIO_Pin_10;
    gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpio);
	Buzzer_GPIO_Init(); // ������GPIO��ʼ��
	
    USART_InitTypeDef uart = {
        .USART_BaudRate = 115200,
        .USART_WordLength = USART_WordLength_8b,
        .USART_StopBits = USART_StopBits_1,
        .USART_Parity = USART_Parity_No,
        .USART_Mode = USART_Mode_Tx | USART_Mode_Rx,
        .USART_HardwareFlowControl = USART_HardwareFlowControl_None
    };
    USART_Init(USART1, &uart);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);

    NVIC_InitTypeDef nvic = {
        .NVIC_IRQChannel = USART1_IRQn,
        .NVIC_IRQChannelPreemptionPriority = 3,
        .NVIC_IRQChannelSubPriority = 0,
        .NVIC_IRQChannelCmd = ENABLE
    };
    NVIC_Init(&nvic);

    /* 5. �ں˶��� */
    xRxQueue = xQueueCreate(64, sizeof(uint8_t));
    xLedTmr  = xTimerCreate("LED", pdMS_TO_TICKS(500),
                            pdTRUE, NULL, tmrLedCB);
	    xBuzzerTimer = xTimerCreate(
        "BuzzerTimer",                // ��ʱ������
        pdMS_TO_TICKS(BUZZER_INTERVAL_2S), // �������ڣ�2��
        pdTRUE,                       // �Զ����أ������Դ�����
        NULL,                         // �޶�ʱ��ID
        vBuzzerTimerCallback          // �ص�����
    );

    /* 6. ���� */
    xTaskCreate(vHeartTask, "Heart", 256, NULL, 2, NULL);
    xTaskCreate(vUartTask,  "Uart",  512, NULL, 4, NULL);

    /* 7. ���� */
    xTimerStart(xLedTmr, 0);
	xTimerStart(xBuzzerTimer, 0); // ��������
    vTaskStartScheduler();

    return 0;
}

/* ���� ---------------------------------------------------------*/
static void vHeartTask(void *p)
{
    (void)p;
    const char *s = "FreeRTOS Heartbeat\r\n";
    while (1)
    {
        for (const char *t = s; *t; ++t)
        {
            while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
            USART_SendData(USART1, *t);
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

static void vUartTask(void *p)
{
    (void)p;
    uint8_t rx;
    while (1)
    {
        if (xQueueReceive(xRxQueue, &rx, portMAX_DELAY) == pdPASS)
        {
            while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
            USART_SendData(USART1, rx);
            while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
            USART_SendData(USART1, '\r');
            while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
            USART_SendData(USART1, '\n');
        }
    }
}

/* ��ʱ���ص� --------------------------------------------------*/
static void tmrLedCB(TimerHandle_t t)
{
    (void)t;
    LED_PORT->ODR ^= LED_PIN;
}
