#ifndef __LED_H
#define __LED_H
#include "stdint.h"

void LED_Init(void) ;
void LED_Toggle(void);
uint8_t LED_Get_State(void);

void TCRT_Init(void);
uint8_t TCRT_Scan(void);

#endif
