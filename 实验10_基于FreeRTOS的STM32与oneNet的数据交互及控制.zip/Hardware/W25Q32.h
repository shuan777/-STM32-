#ifndef __W25Q32_H
#define __W25Q32_H
#include "stm32f10x.h"                  // Device header


// W25Q32ָ�
#define W25Q32_CMD_WRITE_ENABLE      0x06
#define W25Q32_CMD_WRITE_DISABLE     0x04
#define W25Q32_CMD_READ_DATA         0x03
#define W25Q32_CMD_READ_JEDEC_ID     0x9F
#define W25Q32_CMD_READ_MANUFACTURER_ID 0x90
#define W25Q32_CMD_READ_STATUS_REG1  0x05
#define W25Q32_CMD_READ_STATUS_REG2  0x35
#define W25Q32_CMD_READ_STATUS_REG3  0x15
#define W25Q32_CMD_WRITE_STATUS_REG1 0x01
#define W25Q32_CMD_PAGE_PROGRAM      0x02
#define W25Q32_CMD_SECTOR_ERASE      0x20
#define W25Q32_CMD_CHIP_ERASE        0xC7
#define W25Q32_CMD_POWER_DOWN        0xB9
#define W25Q32_CMD_RELEASE_POWER_DOWN 0xAB


// W25Q32Ƭѡ����
#define W25Q32_CS_LOW()     GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define W25Q32_CS_HIGH()    GPIO_SetBits(GPIOA, GPIO_Pin_4)

// ��������
void W25Q32_Init(void);
uint8_t W25Q32_SendByte(uint8_t byte);

//uint16_t W25Q32_ReadManufacturerID(void);
//uint16_t W25Q32_ReadDeviceID(void);
//void W25Q32_ReadJedecID(uint8_t *manufacturer, uint8_t *memoryType, uint8_t *capacity);

uint8_t W25Q32_EraseSector(uint32_t sector_addr);
uint8_t W25Q32_WritePage(uint32_t addr, uint8_t *data, uint16_t len);
uint8_t W25Q32_ReadData(uint32_t addr, uint8_t *buffer, uint32_t len);

#endif
