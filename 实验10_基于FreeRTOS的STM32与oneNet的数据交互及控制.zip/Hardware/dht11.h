#ifndef __DHT11_H
#define __DHT11_H

#include <stdint.h>

void  DHT11_Init(void);                 // PB12 ��Ϊ DQ
uint8_t DHT11_Read_Data(uint8_t *temp, uint8_t *humi); // 0=OK

#endif
