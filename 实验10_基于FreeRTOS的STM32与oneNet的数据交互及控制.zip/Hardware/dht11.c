#include "dht11.h"
#include "timer_delay.h"
#include "stm32f10x.h"

#define DHT11_GPIO_PORT GPIOA
#define DHT11_GPIO_PIN  GPIO_Pin_1
#define DHT11_RCC_CLK   RCC_APB2Periph_GPIOA

/* ˽�к��� ----------------------------------------------------------*/
static void DHT11_IO_OUT(void)
{
    GPIO_InitTypeDef g;
    g.GPIO_Pin   = DHT11_GPIO_PIN;
    g.GPIO_Mode  = GPIO_Mode_Out_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DHT11_GPIO_PORT, &g);
}

static void DHT11_IO_IN(void)
{
    GPIO_InitTypeDef g;
    g.GPIO_Pin  = DHT11_GPIO_PIN;
    g.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(DHT11_GPIO_PORT, &g);
}

static uint8_t DHT11_Read_Bit(void)
{
    uint16_t cnt;

    /* 1. �ȴ� 50 ��s �͵�ƽ��ʼ */
    cnt = 0;
    while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) == SET && cnt < 100)
        cnt++, TD_us(1);

    /* 2. �ȵ͵�ƽ������0 λ 26 ��s��1 λ 70 ��s�� */
    cnt = 0;
    while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) == RESET && cnt < 100)
        cnt++, TD_us(1);

    /* 3. ����ʱ 26 ��s ������0 λ�ս�����1 λ�Ըߣ� */
    TD_us(30);

    /* 4. ���ص�ǰ��ƽ */
    return GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
}

static uint8_t DHT11_Read_Byte(void)
{
    uint8_t i, data = 0;
    for (i = 0; i < 8; i++) {
        data <<= 1;
        data |= DHT11_Read_Bit();
    }
    return data;
}

/* ����ӿ� ----------------------------------------------------------*/
void DHT11_Init(void)
{
    RCC_APB2PeriphClockCmd(DHT11_RCC_CLK, ENABLE);
    DHT11_IO_OUT();
    GPIO_SetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
}

uint8_t DHT11_Read_Data(uint8_t *temp, uint8_t *humi)
{
    uint8_t buf[5] = {0};
    uint8_t i;

    /* 1. ��ʼ�ź� */
    DHT11_IO_OUT();
    GPIO_ResetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
    TD_ms(20);
    GPIO_SetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
    TD_us(20);
    DHT11_IO_IN();

    /* 2. �����Ӧ */
    if (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) == RESET) {
        uint16_t cnt = 0;
        while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) == RESET && cnt < 100)
            cnt++, TD_us(1);
        cnt = 0;
        while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) == SET && cnt < 100)
            cnt++, TD_us(1);

        /* 3. �� 40 λ */
        for (i = 0; i < 5; i++)
            buf[i] = DHT11_Read_Byte();

        /* 4. У�� */
        if (buf[0] + buf[1] + buf[2] + buf[3] == buf[4]) {
            *humi = buf[0];   // ����
            *temp = buf[2];   // ����
            return 0;         // �ɹ�
        }
    }
    return 1; // ʧ��
}
