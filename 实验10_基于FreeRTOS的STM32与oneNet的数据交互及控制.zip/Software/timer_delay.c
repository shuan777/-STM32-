#include "timer_delay.h"
#include "stm32f10x.h"

static void TD_TIM2_Config(void);

/* ����ӿ� ----------------------------------------------------------*/
void TD_Init(void)
{
    TD_TIM2_Config();          // ֻ����һ��
}

void TD_us(uint16_t us)
{
    TIM_SetCounter(TIM2, 0);
    while (TIM_GetCounter(TIM2) < us);
}

void TD_ms(uint16_t ms)
{
    for (uint16_t i = 0; i < ms; i++)
        TD_us(1000);
}

/* �ڲ����� ----------------------------------------------------------*/
static void TD_TIM2_Config(void)
{
    RCC_ClocksTypeDef rcc;
    TIM_TimeBaseInitTypeDef t;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_GetClocksFreq(&rcc);                       // ��ʵ APB1 Ƶ��
    /* �� APB1 ��Ƶ ��1 ʱ����ʱ��ʱ�� = APB1*2 */
    uint32_t timclk = (rcc.PCLK1_Frequency * 2);
    uint16_t psc = (timclk / 1000000) - 1;       // 1 MHz

    t.TIM_Prescaler = psc;
    t.TIM_CounterMode = TIM_CounterMode_Up;
    t.TIM_Period = 0xFFFF;
    t.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM2, &t);
    TIM_Cmd(TIM2, ENABLE);
}

