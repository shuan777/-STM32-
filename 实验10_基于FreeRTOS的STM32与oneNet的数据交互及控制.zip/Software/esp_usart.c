#include "esp_usart.h"

USART_RingBuf USART2_RxBuf = {0};


// USART2��ʼ����ͬUSART1��
void MyUSART2_Init(uint32_t bound) {
    GPIO_InitTypeDef GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    // TX(PA2)���츴�����
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // RX(PA3)��������
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // USART2����
    USART_InitStruct.USART_BaudRate = bound;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStruct);

    // �ж����ã����ȼ�2��
    NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 6;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    // ��ʹ���ֽڽ����ж�
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART2, ENABLE);
}

// ���ڷ��ͺ���������ʽ��
void MyUSART_SendData(USART_TypeDef* USARTx, uint8_t* data, uint16_t len) {
    if (len == 0 || data == NULL) return;
    for (uint16_t i = 0; i < len; i++) {
        while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
        USART_SendData(USARTx, data[i]);
    }
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
}

// ��ջ����������������ֶΣ�
void USART_ClearBuf(USART_RingBuf* buf) {
	taskENTER_CRITICAL(); // �����ٽ�������ֹ�ж��޸Ļ�����
	buf->head = 0;
    buf->tail = 0;
    buf->len = 0;
    buf->last_byte = 0;
    buf->ready = 0; // ��վ�����־
	taskEXIT_CRITICAL(); // �˳��ٽ���
}



// ͷ�ļ�����
extern volatile uint32_t g_uart2_last_rx_time;  // �ϴν���ʱ��

void USART2_IRQHandler(void) {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint8_t rx_data;
    
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        rx_data = USART_ReceiveData(USART2);
        
        // ��¼����ʱ��
        g_uart2_last_rx_time = xTaskGetTickCountFromISR();
        
        if (USART2_RxBuf.len < USART2_RX_BUF_SIZE) {
            USART2_RxBuf.buf[USART2_RxBuf.tail] = rx_data;
            USART2_RxBuf.tail = (USART2_RxBuf.tail + 1) % USART2_RX_BUF_SIZE;
            USART2_RxBuf.len++;
            
            USART2_RxBuf.last_byte = rx_data;
        } else {
            USART_ClearBuf(&USART2_RxBuf);
        }
        
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
    
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
