#ifndef __USART_H
#define __USART_H

#include "stdio.h"

void USART1_Init(void);
int fputc(int ch,FILE *f);
char USART1_GetChar(void);

#endif

