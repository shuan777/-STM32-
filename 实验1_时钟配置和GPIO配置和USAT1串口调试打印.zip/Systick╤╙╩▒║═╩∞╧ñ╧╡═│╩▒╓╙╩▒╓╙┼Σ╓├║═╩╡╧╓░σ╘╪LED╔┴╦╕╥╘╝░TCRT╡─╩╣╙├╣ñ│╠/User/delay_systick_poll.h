#ifndef __DELAY_SYSTICK_POLL_H
#define __DELAY_SYSTICK_POLL_H

#include "stdint.h"

void DelayPoll_Init(void);
void DelayPoll_ms(uint32_t ms);
void DelayPoll_us(uint32_t us);

#endif
