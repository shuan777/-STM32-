#ifndef __ESP8266_H
#define __ESP8266_H


#include "stm32f10x.h"                  // Device header
#include "esp_usart.h"
#include "timer_delay.h"
#include "stdio.h"
#include "stdlib.h"

// ���巢�ͺͽ��ջ�������С
#define ESP8266_TX_BUF_SIZE 128
#define ESP8266_RX_BUF_SIZE 128

uint8_t ESP8266_SendATCmd(const char* cmd,const char* success_str);
void ESP8266_Init(void);

uint8_t Report_Device_Property(const char *id_str, 
                               const char *prop_name, 
                               const char *prop_value,
                               uint8_t value_type);
void Parse_OneNet_Set_Cmd(void);
void Publish_Property_Set_Reply(void);
void Handle_OneNet_Prop_Set(void);
#endif  
