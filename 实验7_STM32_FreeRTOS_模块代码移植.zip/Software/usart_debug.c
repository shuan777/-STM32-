#include "usart_debug.h"
#include "stm32f10x.h"
#include "stdarg.h"
#include "stdio.h"
#include "FreeRTOS.h"
#include "task.h"

#define TX_BUF_SIZE 256
static uint8_t  tx_buf[TX_BUF_SIZE];
static volatile uint16_t tx_wr = 0, tx_rd = 0;
static TaskHandle_t xTaskToNotify = NULL;

/* �ײ� ----------------------------------------------------------*/
static void USART1_GPIO_Config(void)
{
    GPIO_InitTypeDef g;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    g.GPIO_Pin   = GPIO_Pin_9;               // TX
    g.GPIO_Mode  = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);

    g.GPIO_Pin  = GPIO_Pin_10;               // RX
    g.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &g);
}

static void USART1_NVIC_Config(void)
{
    NVIC_InitTypeDef n;
    n.NVIC_IRQChannel                   = USART1_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 6; // ���� configMAX_SYSCALL
    n.NVIC_IRQChannelSubPriority        = 0;
    n.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&n);
}

/* �����ʼ�� ----------------------------------------------------*/
void USART1_DebugInit(void)
{
    USART_InitTypeDef u;
    USART1_GPIO_Config();

    u.USART_BaudRate            = 115200;
    u.USART_WordLength          = USART_WordLength_8b;
    u.USART_StopBits            = USART_StopBits_1;
    u.USART_Parity              = USART_Parity_No;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    u.USART_Mode                = USART_Mode_Tx;
    USART_Init(USART1, &u);

    USART1_NVIC_Config();
    USART_Cmd(USART1, ENABLE);
}

/* �̰߳�ȫ printf ----------------------------------------------*/
void USART1_Printf(const char *fmt, ...)
{
    va_list ap;
    char tmp[128];
    int len;

    va_start(ap, fmt);
    len = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);

    taskENTER_CRITICAL();
    for (int i = 0; i < len; ++i) {
        tx_buf[tx_wr] = tmp[i];
        tx_wr = (tx_wr + 1) % TX_BUF_SIZE;
    }
    taskEXIT_CRITICAL();

    xTaskToNotify = xTaskGetCurrentTaskHandle();
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
}

/* DHT11 ר�õ������ ------------------------------------------*/
void USART1_PrintDHT11(uint8_t buf[5], uint8_t status)
{
    if (status == 0) {
        uint8_t sum = buf[0] + buf[1] + buf[2] + buf[3];
        USART1_Printf("Raw:%02X %02X %02X %02X %02X  (Sum=0x%02X)\r\n",
                      buf[0], buf[1], buf[2], buf[3], buf[4], sum);
        USART1_Printf("  -> RH:%d.%d%%  T:%d.%d��C\r\n",
                      buf[0], buf[1], buf[2], buf[3]);
    } else {
        USART1_Printf("DHT11 read FAIL  Raw:%02X %02X %02X %02X %02X\r\n",
                      buf[0], buf[1], buf[2], buf[3], buf[4]);
    }
}

/* �жϷ��� ------------------------------------------------------*/
void USART1_IRQHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetITStatus(USART1, USART_IT_TXE) != RESET) {
        if (tx_rd != tx_wr) {
            USART_SendData(USART1, tx_buf[tx_rd]);
            tx_rd = (tx_rd + 1) % TX_BUF_SIZE;
        } else {
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
            if (xTaskToNotify) {
                vTaskNotifyGiveFromISR(xTaskToNotify, &xHigherPriorityTaskWoken);
                xTaskToNotify = NULL;
            }
        }
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}



