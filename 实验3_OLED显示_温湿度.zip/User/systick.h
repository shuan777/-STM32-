#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stdint.h"

void Systick_Init(void);
uint32_t Get_System_Time(void);
void Delay_Ms(uint32_t ms);
void Delay_Us(uint32_t us);

#endif
