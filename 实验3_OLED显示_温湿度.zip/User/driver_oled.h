#ifndef __DRIVER_H
#define __DRIVER_H
#include "stdint.h"

// OLED�Դ�ߴ�
#define OLED_WIDTH  128
#define OLED_HEIGHT 64

//static void I2C1_Init(void);
//static void I2C_Write_Byte(uint8_t addr, uint8_t data);
//void OLED_Write_Command(uint8_t cmd);
//void OLED_Write_Data(uint8_t data);
//void OLED_Set_Pos(uint8_t x, uint8_t y);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowString(uint8_t x, uint8_t y, char *str);
void OLED_ShowChar(uint8_t x, uint8_t y, char ch) ;
void OLED_ShowNum(uint8_t x, uint8_t y, uint32_t num, uint8_t len);
	
#endif  

