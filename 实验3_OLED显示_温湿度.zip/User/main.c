#include "stm32f10x.h"    // Device header
#include  "stdio.h"
#include "systick.h"
#include "usart.h"
#include "led.h"
#include "driver_oled.h"
#include "dht11.h"


int main(void)
{    
	uint8_t buffer[5];
    // 2. ��ʼ����ģ��
	
    Systick_Init();      // SysTick 1us�ж�
	USART1_Init();		//��ʼ��OLED
	LED_Init();
	OLED_Init();
	
	Delay_Ms(2000);
    OLED_ShowString(0,0,"zhangliwen");
	OLED_ShowString(0,2,"Himidity:  %");
	OLED_ShowString(0,4,"Temp:  ");
	
    // 4. ��ѭ������֤���й���
    while(1)
	{
		

		if(DHT_ReadData(buffer)==0)
		{
			printf("ʪ��:%d %%RH,�¶�:%d��\r\n",
			buffer[0],buffer[2]);
			OLED_ShowNum(73,2,buffer[0],2);
			OLED_ShowNum(41,4,buffer[2],2);
		}
		
		else
		{
			printf("DHT11���ݶ�ȡʧ��\r\n");
		
		}
//		
//		Delay_Ms(1000);
//		LED_Toggle();
		Delay_Ms(5000);
		

	}
        
}

